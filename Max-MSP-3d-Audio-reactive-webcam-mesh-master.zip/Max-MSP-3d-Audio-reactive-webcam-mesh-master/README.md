# Max-MSP-3d-Audio-reactive-webcam-mesh

This is a Max/MSP patch that can transform your webcam image into a 3D mesh, which can be controlled by sound.

www.musiconerd.com

by Gustavo Silveira
